package com.ofa.oneforallfitness.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.ofa.oneforallfitness.R;

import java.util.concurrent.TimeUnit;

public class MobileLoginActivity extends AppCompatActivity {
    Button sendotp_btn,otplogin;
    LinearLayout otplayout;
    EditText phoneno, otpinput,et1,et2,et3,et4,et5,et6;
    private String userphoneno = "", enteredotp = "";
    String mverificationId;
    PhoneAuthProvider.ForceResendingToken mtoken;
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    FirebaseAuth mAuth;
    FirebaseUser user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mobile_login);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        sendotp_btn = findViewById(R.id.sendotp_login_btn);
        phoneno = findViewById(R.id.phonenumber_otp);
        et1=findViewById(R.id.etotp1);
        et2=findViewById(R.id.etotp2);
        et3=findViewById(R.id.etopt3);
        et4=findViewById(R.id.etotp4);
        et5=findViewById(R.id.etotp5);
        et6=findViewById(R.id.etotp6);
        otplayout=findViewById(R.id.otpinputlayer);
        otplogin=findViewById(R.id.login_otp_btn);
        otpinput=findViewById(R.id.etotp1);
        otplayout.setVisibility(View.INVISIBLE);


        et1.addTextChangedListener(new GenericTextWatcher(et1));
        et2.addTextChangedListener(new GenericTextWatcher(et2));
        et3.addTextChangedListener(new GenericTextWatcher(et3));
        et4.addTextChangedListener(new GenericTextWatcher(et4));

        mAuth = FirebaseAuth.getInstance();
        sendotp_btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                userphoneno = phoneno.getText().toString();

                if (userphoneno.isEmpty() || userphoneno.length() < 10 ) {
                    Toast.makeText(getApplicationContext(), "Invalid Phone number", Toast.LENGTH_SHORT).show();
                    return;
                } else {

                   PhoneAuthProvider.getInstance().verifyPhoneNumber("+91"+userphoneno,60,TimeUnit.SECONDS,MobileLoginActivity.this,mCallbacks);
                    Log.i("ofafitnes","Settnig ivs");
                    otplayout.setVisibility(View.VISIBLE);

                }
                otplogin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        verifysignincode();
                    }
                });
                           }
        });
        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {

                Log.d("ofaotp", "onVerificationCompleted:" + credential.getSmsCode());
                signInWithPhoneAuthCredential(credential);
            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                // This callback is invoked in an invalid request for verification is made,
                // for instance if the the phone number format is not valid.
                Log.w("ofa otp", "onVerificationFailed", e);

                if (e instanceof FirebaseAuthInvalidCredentialsException) {
                    // Invalid request
                    // ...
                } else if (e instanceof FirebaseTooManyRequestsException) {
                    // The SMS quota for the project has been exceeded
                    // ...
                }

                // Show a message and update the UI
                // ...
            }

            @Override
            public void onCodeSent(@NonNull String verificationId,
                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
                Log.d("ofa otp", "onCodeSent:" + verificationId);
                super.onCodeSent(verificationId,token);
                // Save verification ID and resending token so we can use them later
                mverificationId = verificationId;
                mtoken = token;


            }
        };




    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("ofa", "signInWithCredential:success");
                            Toast.makeText(getApplicationContext(),"login succesful",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(MobileLoginActivity.this,HomeActivity.class));
                            FirebaseUser user = task.getResult().getUser();
                            // ...
                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.w("ofa", "signInWithCredential:failure", task.getException());
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                                otpinput.setError("Invalid otp");

                            }
                        }
                    }
                });
    }

    public void verifysignincode() {
        String otp1="",otp2="",otp3="",otp4="",otp5="",otp6="";
        otp1=et1.getText().toString();
        otp2=et2.getText().toString();
        otp3=et3.getText().toString();
        otp4=et4.getText().toString();
        otp5=et5.getText().toString();
        otp6=et6.getText().toString();
        String inputotp=otp1+otp2+otp3+otp4+otp5+otp6;
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(mverificationId,inputotp);
                 signInWithPhoneAuthCredential(credential);
    }


    public class GenericTextWatcher implements TextWatcher
    {
        private View view;
        private GenericTextWatcher(View view)
        {
            this.view = view;
        }

        @Override
        public void afterTextChanged(Editable editable) {
            // TODO Auto-generated method stub
            String text = editable.toString();
            switch(view.getId())
            {

                case R.id.etotp1:
                    if(text.length()==1)
                        et2.requestFocus();
                    break;
                case R.id.etotp2:
                    if(text.length()==1)
                        et3.requestFocus();
                    else if(text.length()==0)
                        et1.requestFocus();
                    break;
                case R.id.etopt3:
                    if(text.length()==1)
                        et4.requestFocus();
                    else if(text.length()==0)
                        et2.requestFocus();
                    break;
                case R.id.etotp4:
                    if(text.length()==0)
                        et3.requestFocus();
                    else if(text.length()==1)
                        et5.requestFocus();
                    break;
                case R.id.etotp5:
                    if(text.length()==0)
                        et4.requestFocus();
                    else if(text.length()==1)
                        et6.requestFocus();
                    break;
                case R.id.etotp6:
                    if(text.length()==1)
                        et6.requestFocus();
                     break;

            }
        }

        @Override
        public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
            // TODO Auto-generated method stub
        }

        @Override
        public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
            // TODO Auto-generated method stub
        }
    }
}
