package com.ofa.oneforallfitness;

public class GymModel {
    String name;
    String address;
    String charges;
    String offer;
    String rating;
    String description;
    int imgid;
}
