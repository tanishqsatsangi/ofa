package com.ofa.oneforallfitness.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import com.ofa.oneforallfitness.Fragments.LoginFragment;
import com.ofa.oneforallfitness.MAsterTrainerFragment;
import com.ofa.oneforallfitness.R;

public class AccountantPlansActivity extends AppCompatActivity {

    TextView master,normal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accountant_plans);

    master=findViewById(R.id.master_button);
    normal=findViewById(R.id.normal_button);
    loadmaster();


    }

    public void loadmaster() {
        master.setTextColor(Color.WHITE);
        master.setBackgroundResource(R.drawable.roundshape_buttons);
        normal.setTextColor(Color.BLACK);
        normal.setBackgroundResource(R.drawable.roundshape_white);

        loadFragment(new MAsterTrainerFragment());
    }

    public void loadFragment(Fragment fragment) {
        if (getSupportFragmentManager().findFragmentById(R.id.planframelayout) != null) {
            getSupportFragmentManager()
                    .beginTransaction().
                    remove(getSupportFragmentManager().findFragmentById(R.id.planframelayout)).commit();
        }
        androidx.fragment.app.FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.planframelayout, fragment);
        fragmentTransaction.commit();

    }

}
