package com.ofa.oneforallfitness.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.ofa.oneforallfitness.Adapters.Offer_Home_Adapter;
import com.ofa.oneforallfitness.dailycrunch.CrunchActivity;
import com.ofa.oneforallfitness.faq.FaqsActivity;
import com.ofa.oneforallfitness.FitFreakBundleActivity;
import com.ofa.oneforallfitness.GymsActivity;
import com.ofa.oneforallfitness.R;
import com.ofa.oneforallfitness.WholeBowlActivity;

import java.util.ArrayList;
import java.util.Arrays;

public class HomeActivity extends AppCompatActivity {

    RecyclerView offerrecyclerview;
    ImageView membership1, membership2;

    ImageView cartbtn;
    private ActionBarDrawerToggle mtoggle;
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    private static final Integer[] IMAGES = {R.drawable.offer1, R.drawable.offer2,R.drawable.offer3};
    private ArrayList<Integer> ImagesArray = new ArrayList<Integer>(Arrays.asList(IMAGES));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        drawerLayout = findViewById(R.id.profile_drawerlayout);
        navigationView = findViewById(R.id.navigation);

        //offer slider
        offerrecyclerview = findViewById(R.id.slider_offer_home);
        offerrecyclerview.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        offerrecyclerview.setHasFixedSize(true);
        Offer_Home_Adapter adapter = new Offer_Home_Adapter(HomeActivity.this, ImagesArray);
        offerrecyclerview.setAdapter(adapter);

        //custom hamburger nav drawer fuctionality
        findViewById(R.id.custom_navdrawericon).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(drawerLayout.isDrawerOpen(Gravity.LEFT)){
                    drawerLayout.closeDrawer(Gravity.LEFT);
                }
                else {
                    drawerLayout.openDrawer(Gravity.LEFT);
                }
            }
        });

        membership1 = findViewById(R.id.memebership_plan1_img);
        membership2 = findViewById(R.id.memebership_plan1_img);
        cartbtn = findViewById(R.id.home_cartbtn);
        //tailored plan click listners
        findViewById(R.id.home_crunch_icon).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, CrunchActivity.class));
            }
        });

        findViewById(R.id.home_whole_bowl_icon).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, WholeBowlActivity.class));
            }
        });

        findViewById(R.id.home_fitness_accounant_icon).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this,FitnessAccountantActivity.class));
            }
        });
        // cart activity
        cartbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, CartActivity.class));
            }
        });

        //membership dialog
        membership1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(HomeActivity.this, FitFreakBundleActivity.class));
        }

        });
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //limking to views
        //drawers and navigation drawer
       // mtoggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close);
        //drawerLayout.addDrawerListener(mtoggle);
       // mtoggle.syncState();
        //navigation drawer listener
        navigationView.setItemIconTintList(null);
        Menu menu=navigationView.getMenu();
        MenuItem nav_logout=menu.findItem(R.id.nav_logout);
        if(FirebaseAuth.getInstance().getCurrentUser()!=null){
            nav_logout.setTitle("Logout");
        }
        else {
            nav_logout.setTitle("Log In");
            nav_logout.setIcon(R.drawable.icon_name);
        }
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.nav_getpass) {
                    startActivity(new Intent(HomeActivity.this, ProfileActivity.class));
                }
                if (id == R.id.nav_store) {
                    startActivity(new Intent(HomeActivity.this, StoreActivity.class));
                }
                if (id == R.id.nav_wishlist) {
                    startActivity(new Intent(HomeActivity.this, WishListActivity.class));
                }
                if(id == R.id.nav_faq){
                    startActivity(new Intent(HomeActivity.this, FaqsActivity.class));
                }

                if (id == R.id.nav_support) {
                    startActivity(new Intent(HomeActivity.this, SupportActivity.class));
                }
                if (id == R.id.nav_logout) {

                        if(FirebaseAuth.getInstance().getCurrentUser()!=null){


                            GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                                    .requestIdToken(getString(R.string.default_web_client_id))
                                    .requestEmail()
                                    .build();
                            GoogleSignInClient mGoogleSignInClient = GoogleSignIn.getClient(getApplicationContext(), gso);
                            mGoogleSignInClient.signOut().addOnCompleteListener(HomeActivity.this, new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (FirebaseAuth.getInstance().getCurrentUser() != null) {
                                        FirebaseAuth.getInstance().signOut();

                                        Toast.makeText(getApplicationContext(), "Logout succsefull", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(HomeActivity.this, LoginActivity.class));
                                        finish();
                                    }
                                }
                            });
                        }
                        else{
                            startActivity(new Intent(HomeActivity.this,LoginActivity.class));
                            finish();
                        }

                    //end logout
                }
                return true;
            }
        });
    }//end of oncreate
    //ecplore fitness world icon clicking  open gym page

    public  void opengympage(View v){
        startActivity(new Intent(HomeActivity.this, GymsActivity.class));
    }

    //on click for forward icons

    public void  forwardicon(View v){
        Toast.makeText(getApplicationContext(),"Coming Soon...stay tuned",Toast.LENGTH_SHORT).show();
    }

    //navigation drawer
       @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (mtoggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 2000);
    }
}