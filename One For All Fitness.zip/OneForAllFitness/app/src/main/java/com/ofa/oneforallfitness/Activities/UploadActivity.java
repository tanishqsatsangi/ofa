package com.ofa.oneforallfitness.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.ofa.oneforallfitness.R;

public class UploadActivity extends AppCompatActivity {
        Bitmap bitmap;
        ImageView img;
    DatabaseReference databaseReference;
    StorageReference storageReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);

        img=findViewById(R.id.tstimg);
        databaseReference= FirebaseDatabase.getInstance().getReference("offers");
        findViewById(R.id.uploadbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String s="";
                        for (DataSnapshot postsnapshot : dataSnapshot.getChildren()) {
                             s=postsnapshot.getValue().toString();
                            Log.i("snap",""+postsnapshot);
                            Log.i("snap",""+postsnapshot.getValue());
                        }
                        Log.i("snap",""+dataSnapshot);
                        Toast.makeText(UploadActivity.this, ""+s, Toast.LENGTH_SHORT).show();
                        Glide.with(UploadActivity.this).load(Uri.parse(s)).into(img);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                            Log.i("db",""+databaseError.getMessage());
                    }


                });
            }
        });
    }

}
