package com.ofa.oneforallfitness.store;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.ofa.oneforallfitness.R;

public class StoreDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_details);
    }
}
