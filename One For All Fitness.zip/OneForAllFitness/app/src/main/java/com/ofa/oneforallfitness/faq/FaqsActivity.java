package com.ofa.oneforallfitness.faq;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.ofa.oneforallfitness.R;

public class FaqsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faqs);
        findViewById(R.id.faq_fitness_accountant).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FaqsActivity.this,FaqFitnessAccountantActivity.class));
            }
        });
        findViewById(R.id.faq_whole_bowl).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FaqsActivity.this,FaqwholebowlActivity.class));
            }
        });
        findViewById(R.id.faq_crunch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FaqsActivity.this,FaqcrunchActivity.class));
            }
        });
    }
}
