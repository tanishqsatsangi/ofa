package com.ofa.oneforallfitness.faq;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.ofa.oneforallfitness.Adapters.FaqAdapter;
import com.ofa.oneforallfitness.R;

public class FaqFitnessAccountantActivity extends AppCompatActivity {
ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faq_fitness_accountant);

        listView=findViewById(R.id.faqlist);
        FaqAdapter adapter=new FaqAdapter(FaqFitnessAccountantActivity.this,0,getResources().getStringArray(R.array.faqfitnessaccountantarray));
        listView.setAdapter(adapter);
    }
}
