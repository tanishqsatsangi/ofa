package com.ofa.oneforallfitness;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.ofa.oneforallfitness.Adapters.FitFreakAdapter;

public class FitFreakBundleActivity extends AppCompatActivity {

    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fit_freak_bundle);
    listView=findViewById(R.id.fitfreak_details_listview);
        FitFreakAdapter adapter=new FitFreakAdapter(FitFreakBundleActivity.this,0,getResources().getStringArray(R.array.fitfreakbundle));
       listView.setAdapter(adapter);
    }
}
