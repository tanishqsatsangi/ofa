package com.ofa.oneforallfitness.Fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ofa.oneforallfitness.R;

public class OfferDeatailFragment extends Fragment {

    public OfferDeatailFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_offer_deatail, container, false);
       v.findViewById(R.id._offer_description_close).setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               getActivity().getSupportFragmentManager().beginTransaction().remove(OfferDeatailFragment.this).commit();
           }
       });
        return  v;
    }

}
