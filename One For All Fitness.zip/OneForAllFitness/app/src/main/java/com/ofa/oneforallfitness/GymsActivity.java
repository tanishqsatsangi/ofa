package com.ofa.oneforallfitness;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.ofa.oneforallfitness.Activities.StoreActivity;
import com.ofa.oneforallfitness.Adapters.GymLIstAdapter;
import com.ofa.oneforallfitness.Adapters.StoreRecyclerAdapter;

public class GymsActivity extends AppCompatActivity {
    RecyclerView gymrecyclerview;
    GymLIstAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gyms);
        gymrecyclerview=findViewById(R.id.gyms_list);
        gymrecyclerview.setHasFixedSize(true);
        gymrecyclerview.setLayoutManager(new LinearLayoutManager(GymsActivity.this));
        adapter=new GymLIstAdapter(GymsActivity.this);
        gymrecyclerview.setAdapter(adapter);

    }
}
