package com.ofa.oneforallfitness.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ofa.oneforallfitness.R;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartHolder> {
   public CartAdapter(){

   }
   public CartAdapter(Context context){

   }

    @NonNull
    @Override
    public CartHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
      View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_list_layout,parent,false);
        return new CartHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CartHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 10;
    }

    public  class CartHolder extends RecyclerView.ViewHolder{

        public CartHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
