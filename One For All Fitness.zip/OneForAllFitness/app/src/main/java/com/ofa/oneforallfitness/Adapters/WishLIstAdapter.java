package com.ofa.oneforallfitness.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ofa.oneforallfitness.R;

public class WishLIstAdapter extends  RecyclerView.Adapter<WishLIstAdapter.WishlistViewHolder> {
   Context mcontext;
    public WishLIstAdapter(){
    //empty constructor
    }

    public WishLIstAdapter(Context context){

    }
    @NonNull
    @Override
    public WishlistViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View v=inflater.inflate(R.layout.wishlist_item_layout,parent,false);
        return new WishlistViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull WishlistViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 10;
    }

    public class WishlistViewHolder extends RecyclerView.ViewHolder{

        public WishlistViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
