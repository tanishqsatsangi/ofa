package com.ofa.oneforallfitness.Adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ofa.oneforallfitness.R;
import com.ofa.oneforallfitness.store.StoreDetailsActivity;
import com.ofa.oneforallfitness.store.StoreItems;

import java.util.ArrayList;

public class StoreRecyclerAdapter extends RecyclerView.Adapter<StoreRecyclerAdapter.StoreViewHolder> {
    Context mcontext;
    ArrayList<StoreItems> storeItemsArrayList =new ArrayList<>();
    public  StoreRecyclerAdapter(){

    }

    public StoreRecyclerAdapter(Context context, ArrayList<StoreItems> marray){
        mcontext=context;
storeItemsArrayList=marray;

    }

    @NonNull
    @Override
    public StoreViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view =inflater.inflate(R.layout.store_item_layout,parent,false);
        return new StoreViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoreViewHolder holder, int position) {
        StoreItems currentitem=storeItemsArrayList.get(position);
       Glide.with(mcontext).load(Uri.parse(currentitem.getImgurl())).into(holder.itemimg);
        Log.i("hodname",""+currentitem.getImgurl());
      holder.itemname.setText(currentitem.getName());
      String s=""+String.valueOf(currentitem.getPrice());
       holder.itemprice.setText("Rs."+s);
       holder.itemprice.setPaintFlags(holder.itemprice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
       String st=String.valueOf(currentitem.getOfferprice());
       holder.itemofferprice.setText(st);
        Log.i("def",""+holder.itemname.getText().toString());
        holder.store_container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mcontext.startActivity(new Intent(mcontext,StoreDetailsActivity.class));
            }
        });
        holder.itemseller.setText(currentitem.getSellername());
        holder.itemcategory.setText(currentitem.getCategory());
    }

    @Override
    public int getItemCount() {
        return storeItemsArrayList.size();
    }

    public  class StoreViewHolder extends  RecyclerView.ViewHolder{
 public ImageView itemimg;
 public  TextView itemname,itemprice,itemofferprice,itemseller,itemcategory;

    public RelativeLayout store_container;

        public StoreViewHolder(@NonNull View itemView) {
            super(itemView);
            itemseller=itemView.findViewById(R.id.store_item_sellername);
            itemimg=itemView.findViewById(R.id.store_item_img);
            itemname = itemView.findViewById(R.id.store_item_name);
            itemprice=itemView.findViewById(R.id.store_item_price);
            itemofferprice=itemView.findViewById(R.id.store_item_offer_price);
        store_container=itemView.findViewById(R.id.storeitem_layout_container);
        itemcategory=itemView.findViewById(R.id.store_item_category);
        }

    }
}
