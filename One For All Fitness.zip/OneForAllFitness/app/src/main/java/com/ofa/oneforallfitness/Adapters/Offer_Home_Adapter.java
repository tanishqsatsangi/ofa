package com.ofa.oneforallfitness.Adapters;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ofa.oneforallfitness.R;

import java.util.ArrayList;

public class Offer_Home_Adapter extends RecyclerView.Adapter<Offer_Home_Adapter.OfferViewholder> {
   private Context mcontext;
   ArrayList<Integer> offerimgarr=new ArrayList<>();
    public Offer_Home_Adapter(){
        //empty constructor
    }
    public Offer_Home_Adapter(Context context,ArrayList<Integer> arr){
        mcontext=context;
        offerimgarr=arr;
    }
    @NonNull
    @Override
    public OfferViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View v=inflater.inflate(R.layout.home_offer_item_layout,parent,false);
        return new OfferViewholder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final OfferViewholder holder, int position) {
            int i=offerimgarr.get(position);
            holder.offerimg.setImageResource(i);
    }

    @Override
    public int getItemCount() {
        return offerimgarr.size();
    }

    public  class  OfferViewholder extends RecyclerView.ViewHolder{
    ImageView offerimg;
        public OfferViewholder(@NonNull View itemView) {
            super(itemView);
            offerimg=itemView.findViewById(R.id.home_offer_item_img);
        }

    }
}
