package com.ofa.oneforallfitness.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ofa.oneforallfitness.Activities.GymDetailActivity;
import com.ofa.oneforallfitness.R;

public class GymLIstAdapter extends RecyclerView.Adapter<GymLIstAdapter.gymviewholder> {

    Context mcontext;

    public  GymLIstAdapter(){

    }

    public  GymLIstAdapter(Context context){
        mcontext=context;
    }


    @NonNull
    @Override
    public gymviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.gym_list_layout,parent,false);
        return new gymviewholder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull gymviewholder holder, int position) {
        holder.bookslot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mcontext.startActivity(new Intent(mcontext, GymDetailActivity.class));
            }
        });
    }

    @Override
    public int getItemCount() {
        return 10;
    }

    public  class gymviewholder extends RecyclerView.ViewHolder{

        public Button bookslot;
        public gymviewholder(@NonNull View itemView) {
            super(itemView);
            TextView gymname=itemView.findViewById(R.id.gym_name);
            bookslot=itemView.findViewById(R.id.gym_bookslot);
        }
    }
}
