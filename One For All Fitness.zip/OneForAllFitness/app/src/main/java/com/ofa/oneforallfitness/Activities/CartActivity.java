package com.ofa.oneforallfitness.Activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ofa.oneforallfitness.Adapters.CartAdapter;
import com.ofa.oneforallfitness.R;

import java.util.ArrayList;

public class CartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
/*
        RecyclerView gymrecyclerview;
        gymrecyclerview = findViewById(R.id.cart_list);
        gymrecyclerview.setHasFixedSize(true);
        gymrecyclerview.setLayoutManager(new LinearLayoutManager(CartActivity.this));




        CartAdapter adapter = new CartAdapter(CartActivity.this);
        gymrecyclerview.setAdapter(adapter);
*/

    }
}
