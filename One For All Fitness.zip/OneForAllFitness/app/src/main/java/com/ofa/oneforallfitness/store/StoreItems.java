package com.ofa.oneforallfitness.store;

public class StoreItems {
    int itemid;
    String name;
    String sellername;
    String description;
    double price;
    double offerprice;
    String imgurl;
    String category;
    public StoreItems() {
        //empty consrtuctor
    }

    public StoreItems(int itemid, String name, String description, double price, double offerprice, String sellername, String imgurl,String category) {
        this.itemid = itemid;
        this.name = name;
        this.description = description;
        this.price = price;
        this.imgurl = imgurl;
        this.offerprice = offerprice;
        this.sellername = sellername;
        this.category=category;
    }

    public int getItemid() {
        return itemid;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public double getOfferprice() {
        return offerprice;
    }

    public String getSellername() {
        return sellername;
    }

    public String getImgurl() {
        return imgurl;
    }

    public String getCategory(){ return category;}
}
