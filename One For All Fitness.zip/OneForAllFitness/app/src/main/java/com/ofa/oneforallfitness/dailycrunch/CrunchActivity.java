package com.ofa.oneforallfitness.dailycrunch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.ofa.oneforallfitness.Activities.CrunchPlansActivity;
import com.ofa.oneforallfitness.Adapters.FitFreakAdapter;
import com.ofa.oneforallfitness.R;

public class CrunchActivity extends AppCompatActivity {
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crunch);

        listView=findViewById(R.id.fitfreak_details_listview);
        FitFreakAdapter adapter=new FitFreakAdapter(CrunchActivity.this,0,getResources().getStringArray(R.array.crunchplan));
        listView.setAdapter(adapter);

        findViewById(R.id.buypassbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CrunchActivity.this, CrunchPlansActivity.class));
            }
        });
    }
}
