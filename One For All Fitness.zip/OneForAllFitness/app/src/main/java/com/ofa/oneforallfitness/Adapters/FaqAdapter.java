package com.ofa.oneforallfitness.Adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ofa.oneforallfitness.R;

public class FaqAdapter extends ArrayAdapter<String> {
    String array[];
    public FaqAdapter(@NonNull Context context, int resource, @NonNull String[] objects) {
        super(context, resource, objects);
        array=objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        convertView= LayoutInflater.from(getContext()).inflate(R.layout.itemdescription_layout,null,false);
        TextView details=convertView.findViewById(R.id.text_description);
        ImageView pointer=convertView.findViewById(R.id.pointer_img);
     String s=array[position];
     if(s.charAt(s.length()-1)=='?'){

         pointer.setImageResource(R.drawable.ic_question_icon);
         details.setTextColor(parent.getResources().getColor(R.color.colorPrimary));

     }
     else {
         details.setTextColor(Color.BLACK);
     }
        details.setText(array[position]);
        return convertView;

    }
}
