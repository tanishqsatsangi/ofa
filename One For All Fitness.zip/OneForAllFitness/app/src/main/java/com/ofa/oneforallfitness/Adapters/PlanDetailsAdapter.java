package com.ofa.oneforallfitness.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ofa.oneforallfitness.R;

import java.util.ArrayList;

public class PlanDetailsAdapter extends RecyclerView.Adapter<PlanDetailsAdapter.Holder> {
    ArrayList<String > al=new ArrayList<>();
        Context context;
    public PlanDetailsAdapter(Context c, ArrayList<String> al) {
        this.al = al;
        context=c;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.plandetail_recycler_layout,parent,false);

        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
holder.textView.setText(al.get(position));
    }

    @Override
    public int getItemCount() {
        return al.size();
    }

    public  class Holder extends RecyclerView.ViewHolder{

        TextView textView;
        public Holder(@NonNull View itemView) {
            super(itemView);
        textView=itemView.findViewById(R.id.text_description);
        }
    }
}
