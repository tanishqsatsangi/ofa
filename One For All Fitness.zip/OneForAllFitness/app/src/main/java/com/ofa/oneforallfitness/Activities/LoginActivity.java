package com.ofa.oneforallfitness.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.ofa.oneforallfitness.Fragments.LoginFragment;
import com.ofa.oneforallfitness.R;
import com.ofa.oneforallfitness.Fragments.SignupFragment;

public class LoginActivity extends AppCompatActivity {
    private ImageView bg_img;

    private TextView loginbutton, signupbutton;
    FrameLayout login_fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginbutton = findViewById(R.id.login_button);
        signupbutton = findViewById(R.id.signup_button);
        login_fragment = findViewById(R.id.login_fragment_container);
        findViewById(R.id.skipbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,HomeActivity.class));
            }
        });
        //load signin as first screen
        loadsigin();

        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadsigin();
            }
        });
        signupbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadsignup();
            }
        });
    }

    public void loadsigin() {
        loginbutton.setTextColor(Color.WHITE);
        loginbutton.setBackgroundResource(R.drawable.roundshape_buttons);
        signupbutton.setTextColor(Color.BLACK);
        signupbutton.setBackgroundResource(R.drawable.roundshape_white);

        loadFragment(new LoginFragment());
    }

    public void loadsignup() {
        signupbutton.setTextColor(Color.WHITE);
        signupbutton.setBackgroundResource(R.drawable.roundshape_buttons);
        // loginbutton.setBackgroundColor(Color.WHITE);
        loginbutton.setTextColor(Color.BLACK);
        loginbutton.setBackgroundResource(R.drawable.roundshape_white);
        loadFragment(new SignupFragment());
    }

    public void loadFragment(Fragment fragment) {
        if (getSupportFragmentManager().findFragmentById(R.id.login_fragment_container) != null) {
            getSupportFragmentManager()
                    .beginTransaction().
                    remove(getSupportFragmentManager().findFragmentById(R.id.login_fragment_container)).commit();
        }
        androidx.fragment.app.FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.login_fragment_container, fragment);
        fragmentTransaction.commit();

    }


}