package com.ofa.oneforallfitness.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ofa.oneforallfitness.R;

import java.util.ArrayList;

public class FitFreakAdapter extends ArrayAdapter<String> {

    Context mcontext;
    String[] array;
    public FitFreakAdapter(@NonNull Context context, int resource, @NonNull String[] objects) {
        super(context, resource, objects);
            array=objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
       convertView= LayoutInflater.from(getContext()).inflate(R.layout.itemdescription_layout,null,false);
        TextView details=convertView.findViewById(R.id.text_description);
        details.setText(array[position]);
       return convertView;

    }
}
