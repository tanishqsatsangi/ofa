package com.ofa.oneforallfitness.Fragments;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.ofa.oneforallfitness.Activities.HomeActivity;
import com.ofa.oneforallfitness.Activities.MobileLoginActivity;
import com.ofa.oneforallfitness.R;

import static android.content.ContentValues.TAG;


public class LoginFragment extends Fragment {
    private GoogleSignInClient mGoogleSignInClient;
     private FirebaseAuth mAuth=FirebaseAuth.getInstance();
    Button signinuserbtn;
    EditText signin_email,signin_pswd;
    TextView forgotpassword;
    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        ImageView otplayout=view.findViewById(R.id.otploginbtn);
        signinuserbtn=view.findViewById(R.id.signin_login_btn);
        signin_email=view.findViewById(R.id.sigin_email);
        signin_pswd=view.findViewById(R.id.signin_pswd);
        forgotpassword=view.findViewById(R.id.signin_forgot_pswd);

        signinuserbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signInWithEmailAndPassword(signin_email.getText().toString().trim(),signin_pswd.getText().toString())
                        .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Log.d("signinemail", "signInWithEmail:success");
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    updateUI(user);
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Log.w("signinemail", "signInWithEmail:failure", task.getException());
                                    Toast.makeText(getActivity(), "Authentication failed.",
                                            Toast.LENGTH_SHORT).show();
                                    updateUI(null);
                                }

                                // ...
                            }
                        });
            }
        });

       //call otp activity
        otplayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent(getActivity(), MobileLoginActivity.class));
            }
        });


 //google sign in
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(getActivity(), gso);
        SignInButton signInButton = view.findViewById(R.id.google_signin_btn);
        signInButton.setSize(SignInButton.SIZE_STANDARD);
        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.google_signin_btn:
                        signIn();
                        break;

                }
            }
        });
        //return fragment view
        return view;

    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, 101);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == 101) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account);
            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately
                Log.w("ofa googlesignin", "Google sign in failed", e);
                // ...
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }
    private void firebaseAuthWithGoogle(final GoogleSignInAccount acct) {
        Log.d("ofa signin", "firebaseAuthWithGoogle:" + acct.getId());

        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("ofA signin", "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            if(task.getResult().getAdditionalUserInfo().isNewUser()){
                                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("user");
                                databaseReference.child(user.getUid()).child("username").setValue(acct.getDisplayName().toString());
                                databaseReference.child(user.getUid()).child("useremail").setValue(acct.getEmail().toString());
                                databaseReference.child(user.getUid()).child("Gender").setValue("Not Provided");
                                databaseReference.child(user.getUid()).child("Money").setValue("0");
                                databaseReference.child(user.getUid()).child("Location").setValue("Not Available");
                                databaseReference.child(user.getUid()).child("Puchases").setValue("0");


                            }
                            updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("ofa signin", "signInWithCredential:failure", task.getException());
                            updateUI(null);
                        }

                    }
                });
    }
    public  void updateUI(FirebaseUser user){
        if(user !=null){
            startActivity(new Intent(getActivity(),HomeActivity.class));
        }
    }
}
