package com.ofa.oneforallfitness;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class WholeBowlPlansActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_whole_bowl_plans);
    }
}
