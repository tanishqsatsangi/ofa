package com.ofa.oneforallfitness.Adapters;

import android.content.Context;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ofa.oneforallfitness.Activities.AllOfferActivity;
import com.ofa.oneforallfitness.Fragments.OfferDeatailFragment;
import com.ofa.oneforallfitness.OfferModel;
import com.ofa.oneforallfitness.R;

import java.util.ArrayList;

public class AllOfferAdapter extends RecyclerView.Adapter<AllOfferAdapter.AllofferViewHolder> {
    Context mcontext;
    ArrayList<OfferModel> offerarr =new ArrayList<>();
    public  AllOfferAdapter(){
        //empty constructor
    }
    public  AllOfferAdapter(Context context,ArrayList<OfferModel> arr){
        offerarr=arr;
        mcontext=context;
    }

    @NonNull
    @Override
    public AllofferViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View v=inflater.inflate(R.layout.all_offer_item_layout,parent,false);
        return new AllofferViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AllofferViewHolder holder, int position) {

        OfferModel currentitem= offerarr.get(position);
        Glide.with(mcontext).load(Uri.parse(currentitem.getImgurl())).into(holder.ofrimg);
        holder.viewdetials.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            loadFragment(new OfferDeatailFragment());
            }
        });
    }

    @Override
    public int getItemCount() {
        return offerarr.size();
    }

    public class AllofferViewHolder extends  RecyclerView.ViewHolder{

        ImageView ofrimg;
        TextView viewdetials;
        public AllofferViewHolder(@NonNull View itemView) {
            super(itemView);
            ofrimg=itemView.findViewById(R.id.all_offer_item_img);
            viewdetials=itemView.findViewById(R.id.all_offer_item_details);

        }
    }

    public  void loadFragment(Fragment fragment){
        if(((AllOfferActivity)mcontext).getSupportFragmentManager().findFragmentById(R.id.login_fragment_container) != null) {
            ((AllOfferActivity)mcontext).getSupportFragmentManager()
                    .beginTransaction().
                    remove(((AllOfferActivity)mcontext).getSupportFragmentManager().findFragmentById(R.id.offers_fragment_container)).commit();
        }
        androidx.fragment.app.FragmentManager fragmentManager=((AllOfferActivity)mcontext).getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.login_fragment_container,fragment);
        fragmentTransaction.commit();

    }

}
