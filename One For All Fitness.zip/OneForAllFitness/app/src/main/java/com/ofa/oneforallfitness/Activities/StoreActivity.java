package com.ofa.oneforallfitness.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.ofa.oneforallfitness.Adapters.StoreRecyclerAdapter;
import com.ofa.oneforallfitness.R;
import com.ofa.oneforallfitness.store.StoreItems;

import java.util.ArrayList;

public class StoreActivity extends AppCompatActivity {

    RecyclerView storelistview;
    DatabaseReference databaseReference;
  ArrayList<StoreItems> storeItemsArrayList=new ArrayList<>();
    StoreRecyclerAdapter storeadapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store);
        storelistview=findViewById(R.id.store_list);
        //get data from database
        findViewById(R.id.backicon).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        databaseReference= FirebaseDatabase.getInstance().getReference("Store");
        uploaddata();
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for (DataSnapshot postsnapshot : dataSnapshot.getChildren()) {
                    StoreItems currentitem=postsnapshot.getValue(StoreItems.class);
                           storeItemsArrayList.add(currentitem);
                    Log.i("snap",""+postsnapshot);

                }
                Log.i("snap",""+dataSnapshot);
                Log.i("arr",""+storeItemsArrayList);
                Log.i("size",""+storeItemsArrayList.size());
                storeadapter=new StoreRecyclerAdapter(getApplicationContext(),storeItemsArrayList);
                storelistview.setHasFixedSize(true);
                storelistview.setLayoutManager(new LinearLayoutManager(StoreActivity.this));
                storelistview.setAdapter(storeadapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.i("db",""+databaseError.getMessage());
            }


        });
    }

    public  void  uploaddata(){
    /*    DatabaseReference databaseReference=FirebaseDatabase.getInstance().getReference("Store");
        StoreItems item=new StoreItems(1,"test","descrption",12.00,10.00,"Hello world",
                "https://firebasestorage.googleapis.com/v0/b/one-for-all-fitness.appspot.com/o/alloffers%2Foffer2.jpg?alt=media&token=415ea035-4189-4b4c-a383-d39cde7a5841","Category");
        databaseReference.push().setValue(item);
*/
    }
}
