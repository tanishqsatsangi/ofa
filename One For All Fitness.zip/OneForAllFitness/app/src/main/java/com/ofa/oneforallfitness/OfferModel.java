package com.ofa.oneforallfitness;

public class OfferModel {
    private String imgurl;
    private String description;
    private String id;

    public OfferModel() {
        //empty required constructor
    }

    public String getImgurl() {
        return imgurl;
    }

    public String getDescription() {
        return description;
    }

    public String getId() {
        return id;
    }

    public OfferModel(String imgurl, String description, String id) {
        this.imgurl = imgurl;
        this.description = description;
        this.id = id;
    }

}
