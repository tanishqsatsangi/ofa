package com.ofa.oneforallfitness.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.ofa.oneforallfitness.Adapters.WishLIstAdapter;
import com.ofa.oneforallfitness.R;

public class WishListActivity extends AppCompatActivity {

    RecyclerView wishlistRecycler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wish_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        wishlistRecycler=findViewById(R.id.wishlist_recyclerview);
        WishLIstAdapter wishLIstAdapter =new WishLIstAdapter(getApplicationContext());
        wishlistRecycler.setHasFixedSize(true);
        wishlistRecycler.setLayoutManager(new LinearLayoutManager(this));
        wishlistRecycler.setAdapter(wishLIstAdapter);
    }
}
