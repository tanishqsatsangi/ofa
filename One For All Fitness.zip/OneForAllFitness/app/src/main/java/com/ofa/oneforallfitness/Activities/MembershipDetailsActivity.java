package com.ofa.oneforallfitness.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.ofa.oneforallfitness.R;

public class MembershipDetailsActivity extends AppCompatActivity {

     String  packagechoosen="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_membership_details);
        Intent intent=getIntent();
        packagechoosen=intent.getStringExtra("package");

    }
}
