package com.ofa.oneforallfitness.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.ofa.oneforallfitness.Adapters.AllOfferAdapter;
import com.ofa.oneforallfitness.OfferModel;
import com.ofa.oneforallfitness.R;

import java.util.ArrayList;

public class AllOfferActivity extends AppCompatActivity {
    RecyclerView alloffer_rv;
    DatabaseReference databaseReference;
    ArrayList<OfferModel> offersarray=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_offer);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //database retrieve
        databaseReference= FirebaseDatabase.getInstance().getReference("alloffers");
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                uploadddata();
                for (DataSnapshot postsnapshot : dataSnapshot.getChildren()) {
                    OfferModel currentitem=postsnapshot.getValue(OfferModel.class);
                    offersarray.add(currentitem);
                    Log.i("snap",""+postsnapshot);

                }
                Log.i("snap",""+dataSnapshot);
                Log.i("arr",""+offersarray);
                Log.i("size",""+offersarray.size());

                alloffer_rv=findViewById(R.id.all_offer_recyclerview);
                alloffer_rv.setLayoutManager(new LinearLayoutManager(AllOfferActivity.this));
                alloffer_rv.setHasFixedSize(true);
                AllOfferAdapter allOfferAdapter =new AllOfferAdapter(getApplicationContext(),offersarray);
                alloffer_rv.setAdapter(allOfferAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.i("db",""+databaseError.getMessage());
            }
        });


    }

    public  void uploadddata(){
        DatabaseReference databaseReference=FirebaseDatabase.getInstance().getReference("alloffers");
        OfferModel of=new OfferModel("https://firebasestorage.googleapis.com/v0/b/one-for-all-fitness.appspot.com/o/alloffers%2Foffer2.jpg?alt=media&token=415ea035-4189-4b4c-a383-d39cde7a5841",
                "hekllo test offers","1a");
            databaseReference.push().setValue(of);

    }
}
